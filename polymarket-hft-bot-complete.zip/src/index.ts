import { PolymarketClient } from './clobClient.js';
import { TradingStrategy } from './strategy.js';
import { BotConfig } from './types.js';
import dotenv from 'dotenv';

dotenv.config();

const config: BotConfig = {
  tradeSize: parseFloat(process.env.TRADE_SIZE || '10'),
  maxSpread: parseFloat(process.env.MAX_SPREAD || '0.02'),
  updateIntervalMs: parseInt(process.env.UPDATE_INTERVAL_MS || '1000')
};

async function main() {
  console.log('🚀 Polymarket HFT Bot Starting...');
  
  const client = new PolymarketClient();
  await client.initialize();
  
  const strategy = new TradingStrategy(client, config);
  
  setInterval(async () => {
    await strategy.execute();
  }, config.updateIntervalMs);
  
  process.on('SIGINT', () => process.exit(0));
}

main().catch(console.error);